import eel
eel.init('web')
eel.start('index.html', size=(1000, 600))
